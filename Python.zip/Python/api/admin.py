from django.contrib import admin
from api.models import Task, Bucket

# Register your models here.
class TaskAdmin(admin.ModelAdmin):
    pass

class BucketAdmin(admin.ModelAdmin):
    pass

admin.site.register(Task, TaskAdmin)
admin.site.register(Bucket, BucketAdmin)