from rest_framework import serializers
from .models import Task, Bucket


class TaskSerializers(serializers.ModelSerializer):
    class Meta:
        model = Task
        fields = '__all__'

class BucketSerializers(serializers.ModelSerializer):
    class Meta:
        model = Bucket
        fields = '__all__'