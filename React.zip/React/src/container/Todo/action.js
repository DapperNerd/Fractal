import {fetchTodoList, createTodo, updateTodoAPI, deleteTodoAPI} from "../../apiService";
import { getValue } from "../../utils/commonUtils";

const GET_TODO_LIST_PENDING = 'GET_TODO_LIST_PENDING';
const GET_TODO_LIST_FAILURE = 'GET_TODO_LIST_FAILURE';
const GET_TODO_LIST_SUCCESS = 'GET_TODO_LIST_SUCCESS';

const CREATE_TODO_FAILURE = 'CREATE_TODO_FAILURE';
const CREATE_TODO_SUCCESS = 'CREATE_TODO_SUCCESS';

const UPDATE_TODO_FAILURE = 'UPDATE_TODO_FAILURE';
const UPDATE_TODO_SUCCESS = 'UPDATE_TODO_SUCCESS';

const DELETE_TODO_FAILURE = 'DELETE_TODO_FAILURE';
const DELETE_TODO_SUCCESS = 'DELETE_TODO_SUCCESS';


const setTodoListSuccess = (data) => {
    return{
        type: GET_TODO_LIST_SUCCESS,
        data: data
    };
}

const setTodoListFailure = (data) => {
    return{
        type: GET_TODO_LIST_FAILURE,
        data: data, 
    };
}

const createTodoSuccess = (data) => {
    return{
        type: CREATE_TODO_SUCCESS,
        data: data
    };
}

const createTodoFailure = (data) => {
    return{
        type: CREATE_TODO_FAILURE,
        data: data, 
    };
}

const updateTodoSuccess = (data) => {
    return{
        type: UPDATE_TODO_SUCCESS,
        data: data
    };
}

const updateTodoFailure = (data) => {
    return{
        type: UPDATE_TODO_FAILURE,
        data: data, 
    };
}

const deleteTodoSuccess = (data) => {
    return{
        type: DELETE_TODO_SUCCESS,
        data: data
    };
}

const deleteTodoFailure = (data) => {
    return{
        type: DELETE_TODO_FAILURE,
        data: data, 
    };
}

export const saveTodo = (todoDetails, bucket_id) => {
    return distpatch => {
        let createTodoPayload = {
            title: todoDetails.title,
            completed: false,
            bucket_id: bucket_id
        }
        createTodo(createTodoPayload)
        .then(response => {
            distpatch(createTodoSuccess(response.data));
            distpatch(getTodoList(bucket_id));
        })
        .catch(error => {
            distpatch(createTodoFailure("Error occured"));
        })
    }
} 

export const updateTodo = (todoDetails, bucket_id) => {
    return distpatch => {
        let updateTodoPayload = {
            id: todoDetails.id,
            title: todoDetails.title,
            completed: todoDetails.completed ? true : false,
            bucket_id: bucket_id
        }
        updateTodoAPI(updateTodoPayload)
        .then(response => {
            distpatch(updateTodoSuccess(response.data));
            distpatch(getTodoList(bucket_id));
        })
        .catch(error => {
            distpatch(updateTodoFailure("Error occured"));
        })
    }
} 

export const saveOrUpdateTodo = (todoDetails, id, bucket_id) => {
    return distpatch => {
        if(id){
            console.log(todoDetails)
            distpatch(updateTodo(todoDetails, bucket_id));
        }
        else{
            distpatch(saveTodo(todoDetails, bucket_id));
        }
    }
} 

export const deleteTodo = (id, bucket_id) => {
    return distpatch => {
        deleteTodoAPI(id)
        .then(response => {
            distpatch(deleteTodoSuccess(response.data));
            
            distpatch(getTodoList(bucket_id));
        })
        .catch(error => {
            distpatch(deleteTodoFailure("Error occured"));
        })
    }
} 

export const getTodoList = (id) => {
    return distpatch => {
        fetchTodoList(id)
        .then(response => {
            distpatch(setTodoListSuccess(response.data));
        })
        .catch(error => {
            distpatch(setTodoListFailure("Error occured"));
        })
    }
}
