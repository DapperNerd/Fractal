import { getValue } from "../../utils/commonUtils";

export const initialState = {};

export function todoReducer(state, action) {
  if (state === undefined) {
    state = initialState;
  }
  switch (action.type) {    
    case "GET_TODO_LIST_PENDING":
      return Object.assign({}, state, {
        todo:{
          data: action.data,
          loading: true,
          error: false,
        },
      });
    case "GET_TODO_LIST_FAILURE":
      return Object.assign({}, state, {
        todo: {
          data: action.data,
          loading: false,
          error: true,
        },
      });
    case "GET_TODO_LIST_SUCCESS":
      return Object.assign({}, state, {
        todo: {
          data: action.data,
          loading: false,
          error: false,
        },
      });
    case "CREATE_TODO_FAILURE":
      return Object.assign({}, state, {
        todo: {
          newTodo: action.data,
          loading: false,
          error: true,
        },
      });
    case "CREATE_TODO_SUCCESS":
      return Object.assign({}, state, {
        todo: {
          newTodo: action.data,
          loading: false,
          error: false,
        },
      });
    case "UPDATE_TODO_FAILURE":
      return Object.assign({}, state, {
        todo: {
          newTodo: action.data,
          loading: false,
          error: true,
        },
      });
    case "UPDATE_TODO_SUCCESS":
      return Object.assign({}, state, {
        todo: {
          newTodo: action.data,
          loading: false,
          error: false,
        },
      });
    default:
      return state;
  }
}