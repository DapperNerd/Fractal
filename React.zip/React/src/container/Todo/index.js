import React from "react";
import {connect } from "react-redux";
import {bindActionCreators} from "redux";
import Todo from "../../component/Todo";
import CreateTodo from "../../component/CreateTodo";

import * as todoAction from "./action";

class TodoContainer extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            todo: {},
            bucket_id: 0
        }
    }
    componentWillMount(){
        this.setState({
            ...this.state,
            bucket_id: this.props.match.params.bucket_id
        })
    }

    componentDidMount(){
        let bucket_id = this.props.match.params.bucket_id
        this.props.todoActions.getTodoList(this.state.bucket_id);
    }
    
    saveOrUpdateTodo = (todoDetails, id) => {
        this.props.todoActions.saveOrUpdateTodo(todoDetails, id, this.state.bucket_id);
    }

    onEditClick = (todo_edit) => {
        todo_edit.completed = false
        console.log(todo_edit)
        this.setState({
            todo: todo_edit
        })

    }

    onCompletedClick = (todo) => {
        todo.completed = todo.completed ? false : true;
        this.props.todoActions.updateTodo(todo, this.state.bucket_id);
    }

    onDeleteClick = (id) => {
        this.props.todoActions.deleteTodo(id, this.state.bucket_id)
    }

    render(){
        return(<div className="container">
                <div id="task-container">
                    <CreateTodo saveOrUpdateTodo={this.saveOrUpdateTodo} todo={this.state.todo} bucket_id={this.state.bucket_id}/>
                    <Todo todos={this.props.todos} onEditClick={this.onEditClick} onDeleteClick={this.onDeleteClick} onCompletedClick={this.onCompletedClick} />
                </div>
            </div>);
    }
}

const mapStateToProps = state =>{
    return {todos: state.todoReducer.todo};
}
    
    
const mapDispatchToProps = dispatch => {
    return {
        todoActions: bindActionCreators(todoAction, dispatch)
    }
}

export default connect(mapStateToProps,mapDispatchToProps)(TodoContainer);