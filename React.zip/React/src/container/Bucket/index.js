import React from "react";
import {connect } from "react-redux";
import {bindActionCreators} from "redux";
import Bucket from "../../component/Bucket";
import CreateBucket from "../../component/CreateBucket";

import * as bucketAction from "./action";

class BucketContainer extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            bucket: {}
        }
    }

    componentDidMount(){
        this.props.bucketActions.getBucketList();
    }

    saveBucket = (bucket) => {
        this.props.bucketActions.saveBucket(bucket);
    }

    render(){
        return(<div className="container">
                <div id="task-container">
                    <CreateBucket saveBucket={this.saveBucket}/>
                    <Bucket buckets={this.props.buckets} />
                </div>
            </div>);
    }
}

const mapStateToProps = state =>{
    return {buckets: state.bucketReducer.bucket};
}
    
    
const mapDispatchToProps = dispatch => {
    return {
        bucketActions: bindActionCreators(bucketAction, dispatch)
    }
}

export default connect(mapStateToProps,mapDispatchToProps)(BucketContainer);