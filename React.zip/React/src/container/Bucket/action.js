import {fetchBucketList, createBucket} from "../../apiService";

const GET_BUCKET_LIST_PENDING = 'GET_BUCKET_LIST_PENDING'
const GET_BUCKET_LIST_SUCCESS = 'GET_BUCKET_LIST_SUCCESS'
const GET_BUCKET_LIST_FAILURE = 'GET_BUCKET_LIST_FAILURE'

const CREATE_BUCKET_SUCCESS = 'CREATE_BUCKET_SUCCESS'
const CREATE_BUCKET_FAILURE = 'CREATE_BUCKET_FAILURE'


const setBucketListSuccess = (data) => {
    return {
        type: GET_BUCKET_LIST_SUCCESS,
        data: data
    }
}

const setBucketListFailure = (data) => {
    return {
        type: GET_BUCKET_LIST_FAILURE,
        data: data
    }
}

const createBucketSuccess = (data) => {
    return {
        type: CREATE_BUCKET_SUCCESS,
        data: data
    }
}

const createBucketFailure = (data) => {
    return {
        type: CREATE_BUCKET_FAILURE,
        data: data
    }
}


export const getBucketList = () => {
    return dispatch => {
        fetchBucketList()
        .then(response => {
            dispatch(setBucketListSuccess(response.data))
        })
        .catch(error => {
            dispatch(setBucketListFailure("Error Fetching bucket list"))
        })
    }
}

export const saveBucket = (bucket) => {
    return distpatch => {
        let createbucketPayload = {
            name: bucket,
        }
        createBucket(createbucketPayload)
        .then(response => {
            distpatch(createBucketSuccess(response.data));
            distpatch(getBucketList());
        })
        .catch(error => {
            distpatch(createBucketFailure("Error occured creating bucket"));
        })
    }
} 