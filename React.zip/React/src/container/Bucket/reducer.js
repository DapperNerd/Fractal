
export const initialState = {}

export function bucketReducer(state, action) {
    if(state === undefined){
        state = initialState
    }
    switch(action.type){
        case "GET_BUCKET_LIST_PENDING":
            return Object.assign({}, state, {
                bucket:{
                data: action.data,
                loading: true,
                error: false,
                },
            });
        case "GET_BUCKET_LIST_FAILURE":
            return Object.assign({}, state, {
                bucket: {
                data: action.data,
                loading: false,
                error: true,
                },
            });
        case "GET_BUCKET_LIST_SUCCESS":
            return Object.assign({}, state, {
                bucket: {
                data: action.data,
                loading: false,
                error: false,
                },
            });
        default:
            return state;
    }
}