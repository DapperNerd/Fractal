export const getValue = (obj, expression) => {
    try {
      return expression
        .split(".")
        .reduce((parentObject, currentObjectKey, index) => {        
          if (index === 0) {
            return parentObject;
          }
          return typeof parentObject === "undefined" || parentObject === null
            ? undefined
            : parentObject[currentObjectKey];
        }, obj);
    } catch (e) {
      console.error("Failed to getValue => ", e);
      return undefined;
    }
  };