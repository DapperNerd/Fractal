import TodoContainer from "../container/Todo"
import BucketContainer from "../container/Bucket"

const routes = [
  {
    path: ["/", "/buckets"],
    exact: true,
    component: BucketContainer,
  },
  {
    path: "/todo/:bucket_id",
    exact: true,
    component: TodoContainer,
  },
  ];
  
  export default routes;