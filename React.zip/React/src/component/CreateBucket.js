import React from "react"

export default class CreateBucket extends React.Component {
    constructor(props){
        super(props)
        this.state = {
            bucket: ''
        }
    }

    render(){
        return(<div  id="form-wrapper">
        <form onSubmit={e => {
            e.preventDefault();
            this.props.saveBucket(this.state.bucket);
            this.setState({bucket: ''})
        }}  id="form">
            <div className="flex-wrapper">
                <div style={{flex: 6}}>
                    <input  className="form-control" id="title" onChange={e => {this.setState({bucket: e.target.value})}} value={this.state.bucket}  type="text" name="name" placeholder="Add bucket.." />
                </div>

                <div style={{flex: 1}}>
                    <input id="submit" className="btn btn-warning" type="submit" name="Add" />
                </div>
            </div>
        </form>
    </div>)
    }
}