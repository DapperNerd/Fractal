import React from "react"
import createBrowserHistory from "../history"

export default class Bucket extends React.Component{
    constructor(props){
        super(props)
    }

    render(){
        let buckets = []
        if(this.props.buckets){
            buckets = this.props.buckets.data ? this.props.buckets.data : [];
        }
        return(<>{this.props.buckets &&  
            
            <div  id="list-wrapper">         
                {buckets.map((bucket, index) => {
                return(
                    <div onClick={() => createBrowserHistory.push(`/todo/${bucket.id}/`)} key={bucket.id} className="task-wrapper flex-wrapper">

                        <div  style={{flex:7}}>
                            <span>{bucket.name}</span>
                        </div>

                    </div>
                    )
                })}
            </div>}</>);
    }
}