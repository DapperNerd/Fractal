import React from "react";
import {getValue} from "../utils/commonUtils"

export default class CreateTodo extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            todo: {title: ''}
        }
    }

    componentDidUpdate(previosProp, previousState){
        if(previosProp.todo !== this.props.todo && getValue(this, "this.props.todo.title")){
            this.setState({
                todo: {...this.props.todo}
            })
        }
    }

    render(){
    return(
            <div  id="form-wrapper">
                <form onSubmit={e => {
                    e.preventDefault();
                    this.props.saveOrUpdateTodo(this.state.todo, getValue(this, "this.props.todo.id"), this.state.bucket_id);
                    this.setState({todo: {title: ''}})
                }}  id="form">
                    <div className="flex-wrapper">
                        <div style={{flex: 6}}>
                            <input  className="form-control" id="title" onChange={e => {this.setState({todo: {...this.state.todo, title:e.target.value}})}} value={this.state.todo.title}  type="text" name="title" placeholder="Add task.." />
                        </div>

                        <div style={{flex: 1}}>
                            <input id="submit" className="btn btn-warning" type="submit" name="Add" />
                        </div>
                    </div>
                </form>
            </div>
        );
    }
}

