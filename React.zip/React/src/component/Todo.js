import React from "react";

export default class Todo extends React.Component{
    constructor(props){
        super(props);
    }
    render(){
        let tasks = []
        if(this.props.todos){
            tasks = this.props.todos.data ? this.props.todos.data : [];
        }
        
    return(<>{this.props.todos &&  
            
            <div  id="list-wrapper">         
                {tasks.map((task, index) => {
                return(
                    <div key={task.id} className="task-wrapper flex-wrapper">

                        <div onClick={e => this.props.onCompletedClick(task)} style={{flex:7}}>

                            {task.completed == false ? (
                                <span>{task.title}</span>

                            ) : (

                                <strike>{task.title}</strike>
                            )}

                        </div>

                        <div style={{flex:1}}>
                            <button onClick={e => this.props.onEditClick(task)} className="btn btn-sm btn-outline-info">Edit</button>
                        </div>

                        <div style={{flex:1}}>
                            <button onClick={e => this.props.onDeleteClick(task.id)} className="btn btn-sm btn-outline-dark delete">Delete</button>
                        </div>

                    </div>
                    )
                })}
            </div>}</>);
    }
}

