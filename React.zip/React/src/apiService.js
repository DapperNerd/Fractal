import axios from "axios";

export const fetchTodoList = (id) => {
    return new Promise((resolve, reject) => {
        axios.get(`http://localhost:8000/api/task-list/${id}/`)
        .then(response => resolve(response))
        .catch(error => reject(error));
    })
}

export const createTodo = (todoDetails) => {
    return new Promise((resolve, reject) => {
        axios.post('http://localhost:8000/api/task-create/', todoDetails)
        .then(response => resolve(response))
        .catch(error => reject(error));
    })
}

export const updateTodoAPI = (todoDetails) => {
    return new Promise((resolve, reject) => {
        axios.post(`http://localhost:8000/api/task-update/${todoDetails.id}/`, todoDetails)
        .then(response => resolve(response))
        .catch(error => reject(error));
    })
}

export const deleteTodoAPI = (id) => {
    return new Promise((resolve, reject) => {
        axios.delete(`http://localhost:8000/api/task-delete/${id}/`)
        .then(response => resolve(response))
        .catch(error => reject(error));
    })
}

export const fetchBucketList = () => {
    return new Promise((resolve, reject) => {
        axios.get('http://localhost:8000/api/bucket-list/')
        .then(response => resolve(response))
        .catch(error => reject(error));
    })
}

export const createBucket = (bucketPayload) => {
    return new Promise((resolve, reject) => {
        axios.post('http://localhost:8000/api/bucket-create/', bucketPayload)
        .then(response => resolve(response))
        .catch(error => reject(error));
    })
}