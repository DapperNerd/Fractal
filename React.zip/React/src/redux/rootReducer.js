import { combineReducers } from "redux";
import {todoReducer} from "../container/Todo/reducer"
import {bucketReducer} from "../container/Bucket/reducer"


export default combineReducers({todoReducer, bucketReducer});